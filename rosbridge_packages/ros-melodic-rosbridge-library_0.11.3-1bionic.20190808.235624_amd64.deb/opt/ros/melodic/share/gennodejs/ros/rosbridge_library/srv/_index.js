
"use strict";

let SendBytes = require('./SendBytes.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestEmpty = require('./TestEmpty.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestNestedService = require('./TestNestedService.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestRequestOnly = require('./TestRequestOnly.js')

module.exports = {
  SendBytes: SendBytes,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestEmpty: TestEmpty,
  TestRequestAndResponse: TestRequestAndResponse,
  TestMultipleResponseFields: TestMultipleResponseFields,
  AddTwoInts: AddTwoInts,
  TestArrayRequest: TestArrayRequest,
  TestNestedService: TestNestedService,
  TestResponseOnly: TestResponseOnly,
  TestRequestOnly: TestRequestOnly,
};
