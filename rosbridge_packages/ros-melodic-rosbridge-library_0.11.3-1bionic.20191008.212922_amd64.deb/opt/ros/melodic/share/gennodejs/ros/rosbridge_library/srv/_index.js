
"use strict";

let TestNestedService = require('./TestNestedService.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let SendBytes = require('./SendBytes.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestEmpty = require('./TestEmpty.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')

module.exports = {
  TestNestedService: TestNestedService,
  AddTwoInts: AddTwoInts,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestRequestOnly: TestRequestOnly,
  TestArrayRequest: TestArrayRequest,
  SendBytes: SendBytes,
  TestResponseOnly: TestResponseOnly,
  TestEmpty: TestEmpty,
  TestRequestAndResponse: TestRequestAndResponse,
};
